import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class Clientchatform1 extends JFrame implements ActionListener  {
    static Socket conn;
    JPanel panel;
    JTextField NewMsg;
    JTextArea ChatHistory;
    JButton Send;
String line;
BufferedReader br;
String response;
BufferedReader  is ;
PrintWriter os;
    public Clientchatform1() throws UnknownHostException, IOException {
        panel = new JPanel();
        NewMsg = new JTextField();
        ChatHistory = new JTextArea();
        Send = new JButton("Send");
        this.setSize(500, 500);
        this.setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        panel.setLayout(null);
        this.add(panel);
        ChatHistory.setBounds(20, 20, 450, 360);
        panel.add(ChatHistory);
        NewMsg.setBounds(20, 400, 340, 30);
        panel.add(NewMsg);
        Send.setBounds(375, 400, 95, 30);
        panel.add(Send);
        Send.addActionListener(this);
        conn = new Socket(InetAddress.getByName("Ghost"), 4444);



        ChatHistory.setText("Connected to Server");
        this.setTitle("ET chat");
        while (true) {
            try {
                BufferedReader  is  = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                                 br= new BufferedReader(new InputStreamReader(System.in));
                String line = is.readLine();
                ChatHistory.setText(ChatHistory.getText() + '\n' + "ET Exec:"
                        + line);
            } catch (Exception e1) {
                ChatHistory.setText(ChatHistory.getText() + '\n'
                        + "Message sending fail:Network Error");
                try {
                    Thread.sleep(3000);
                    System.exit(0);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if ((e.getSource() == Send) && (NewMsg.getText() != "")) {

            ChatHistory.setText(ChatHistory.getText() + '\n' + "User:"
                    + NewMsg.getText());
            try {
                             br= new BufferedReader(new InputStreamReader(System.in));
                 PrintWriter os=new PrintWriter(conn.getOutputStream());

                os.println(NewMsg.getText());
                                os.flush();

            } catch (Exception e1) {
                ChatHistory.append(ChatHistory.getText() + '\n'
                        + "Message sending fail:Network Error");

            }


            NewMsg.setText("");
        }
    }

    public static void main(String[] args) throws UnknownHostException,
            IOException {
        Clientchatform1 chatForm = new Clientchatform1();
    }

}
